package sp.senai.br.wineappraiser;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.EditText;
import android.widget.RatingBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Cadastro extends AppCompatActivity {

    String sIP = "10.87.230.24";
    EditText etNome, etOrigem, etTipo;
    RatingBar rbNota;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cadastro);
        //define a politica  de segurança: permissao
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        //================================================================================
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        etNome = findViewById(R.id.etNome);
        etOrigem = findViewById(R.id.etOrigem);
        etTipo = findViewById(R.id.etTipo);
        rbNota = findViewById(R.id.rbNota);
    }
    public void salvar(View s){
        try {
            URL site = new URL("http://"+sIP+":8080/wine/inserirDados.php?"+"nome="+etNome.getText().toString()+"&tipo="+etTipo.getText().toString()+"&origem="+etOrigem.getText().toString()+"&nota="+rbNota.getRating());
            HttpURLConnection conexao = (HttpURLConnection) site.openConnection();
            conexao.connect();
            //le o  fluxo de dados de uma fonte externa permitindo o processamento em tempo real
            InputStream entradaDados = conexao.getInputStream();
            //carrega o main activity e fecha o cadastro
            Intent pri = new Intent(Cadastro.this,MainActivity.class);
            startActivity(pri);
            finish();
        }catch (MalformedURLException m) {
            m.printStackTrace();
        }catch (IOException i){
            i.printStackTrace();
        }
    }
}