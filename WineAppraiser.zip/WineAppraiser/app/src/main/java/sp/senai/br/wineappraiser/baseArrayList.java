package sp.senai.br.wineappraiser;

public class baseArrayList {
    public String id, nome, tipo, origem, nota;
}
